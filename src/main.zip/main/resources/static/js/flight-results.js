const AIRPORT_CACHE_KEY = "travelMoney.airports";

const resultSummary = document.getElementById("resultSummary");
const flightResultGrid = document.getElementById("flightResultGrid");

const compactSearchBar = document.getElementById("compactSearchBar");
const compactRouteText = document.getElementById("compactRouteText");
const compactConditionText = document.getElementById("compactConditionText");

const resultsSearchPanel = document.getElementById("resultsSearchPanel");
const resultsSearchDim = document.getElementById("resultsSearchDim");
const closeResultsSearchPanelBtn = document.getElementById("closeResultsSearchPanelBtn");

const originAirportInput = document.getElementById("originAirportInput");
const destinationAirportInput = document.getElementById("destinationAirportInput");
const originAirportCodeBadge = document.getElementById("originAirportCodeBadge");
const destinationAirportCodeBadge = document.getElementById("destinationAirportCodeBadge");
const originAirportDropdown = document.getElementById("originAirportDropdown");
const destinationAirportDropdown = document.getElementById("destinationAirportDropdown");

const departureDateInput = document.getElementById("departureDateInput");

const travelerPickerButton = document.getElementById("travelerPickerButton");
const travelerPopover = document.getElementById("travelerPopover");
const travelerSummaryText = document.getElementById("travelerSummaryText");

const adultMinusBtn = document.getElementById("adultMinusBtn");
const adultPlusBtn = document.getElementById("adultPlusBtn");
const adultCountText = document.getElementById("adultCountText");

const childMinusBtn = document.getElementById("childMinusBtn");
const childPlusBtn = document.getElementById("childPlusBtn");
const childCountText = document.getElementById("childCountText");

const infantMinusBtn = document.getElementById("infantMinusBtn");
const infantPlusBtn = document.getElementById("infantPlusBtn");
const infantCountText = document.getElementById("infantCountText");

const travelerApplyBtn = document.getElementById("travelerApplyBtn");

const seatClassSelect = document.getElementById("seatClassSelect");
const connectionTypeSelect = document.getElementById("connectionTypeSelect");
const sortSelect = document.getElementById("sortSelect");
const resultsSearchBtn = document.getElementById("resultsSearchBtn");
const swapAirportBtn = document.getElementById("swapAirportBtn");

const resultSortSelect = document.getElementById("resultSortSelect");

const connectionFilterInputs = document.querySelectorAll("input[name='connectionFilter']");
const seatClassFilterInputs = document.querySelectorAll("input[name='seatClassFilter']");

let airports = [];

let selectedOriginAirport = null;
let selectedDestinationAirport = null;

let adultCount = 1;
let childCount = 0;
let infantCount = 0;

let isOriginComposing = false;
let isDestinationComposing = false;

document.addEventListener("DOMContentLoaded", init);

async function init() {
  initializeControlsFromUrl();
    initializeDateLimit();

  bindEvents();
  renderTravelerCount();

  loadAirportsFromCache();
  await loadAirports();

  fetchFlightResults();
}

function initializeControlsFromUrl() {
  const params = getCurrentParams();

  departureDateInput.value = params.get("departureDate") || getTodayText();

  adultCount = Number(params.get("adultCount") || 1);
  childCount = Number(params.get("childCount") || 0);
  infantCount = Number(params.get("infantCount") || 0);

  seatClassSelect.value = params.get("seatClass") || "";
  connectionTypeSelect.value = params.get("connectionType") || "";
  sortSelect.value = params.get("sort") || "PRICE_ASC";
  resultSortSelect.value = params.get("sort") || "PRICE_ASC";

  const connectionType = params.get("connectionType") || "";
  connectionFilterInputs.forEach((input) => {
    input.checked = input.value === connectionType;
  });

  const seatClass = params.get("seatClass") || "";
  seatClassFilterInputs.forEach((input) => {
    input.checked = input.value === seatClass;
  });
}

function bindEvents() {
  compactSearchBar.addEventListener("click", openResultsSearchPanel);
  closeResultsSearchPanelBtn.addEventListener("click", closeResultsSearchPanel);
  resultsSearchDim.addEventListener("click", closeResultsSearchPanel);

  resultsSearchBtn.addEventListener("click", moveToResultsPage);

  swapAirportBtn.addEventListener("click", () => {
    const origin = selectedOriginAirport;
    const destination = selectedDestinationAirport;

    selectedOriginAirport = destination;
    selectedDestinationAirport = origin;

    renderSelectedAirport("origin");
    renderSelectedAirport("destination");
  });

  bindAirportInputEvents("origin");
  bindAirportInputEvents("destination");

  travelerPickerButton.addEventListener("click", (event) => {
    event.stopPropagation();
    travelerPopover.classList.toggle("open");
    closeAirportDropdowns();
  });

  adultMinusBtn.addEventListener("click", () => changePassengerCount("ADULT", -1));
  adultPlusBtn.addEventListener("click", () => changePassengerCount("ADULT", 1));

  childMinusBtn.addEventListener("click", () => changePassengerCount("CHILD", -1));
  childPlusBtn.addEventListener("click", () => changePassengerCount("CHILD", 1));

  infantMinusBtn.addEventListener("click", () => changePassengerCount("INFANT", -1));
  infantPlusBtn.addEventListener("click", () => changePassengerCount("INFANT", 1));

  travelerApplyBtn.addEventListener("click", () => {
    travelerPopover.classList.remove("open");
  });

  resultSortSelect.addEventListener("change", () => {
    sortSelect.value = resultSortSelect.value;
    updateParamAndReload("sort", resultSortSelect.value);
  });

  connectionFilterInputs.forEach((input) => {
    input.addEventListener("change", () => {
      connectionTypeSelect.value = input.value;
      updateParamAndReload("connectionType", input.value);
    });
  });

  seatClassFilterInputs.forEach((input) => {
    input.addEventListener("change", () => {
      seatClassSelect.value = input.value;
      updateParamAndReload("seatClass", input.value);
    });
  });

  document.addEventListener("click", (event) => {
    const clickedInsideTraveler =
      travelerPopover.contains(event.target) ||
      travelerPickerButton.contains(event.target);

    const clickedInsideAirport =
      originAirportDropdown.contains(event.target) ||
      destinationAirportDropdown.contains(event.target) ||
      originAirportInput.contains(event.target) ||
      destinationAirportInput.contains(event.target);

    if (!clickedInsideTraveler) {
      travelerPopover.classList.remove("open");
    }

    if (!clickedInsideAirport) {
      closeAirportDropdowns();
    }
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeResultsSearchPanel();
      closeAirportDropdowns();
      travelerPopover.classList.remove("open");
    }
  });
}

function bindAirportInputEvents(type) {
  const input = type === "origin" ? originAirportInput : destinationAirportInput;

  input.addEventListener("compositionstart", () => {
    if (type === "origin") {
      isOriginComposing = true;
    } else {
      isDestinationComposing = true;
    }
  });

  input.addEventListener("compositionend", () => {
    if (type === "origin") {
      isOriginComposing = false;
    } else {
      isDestinationComposing = false;
    }

    renderAirportDropdown(type, input.value);
  });

  input.addEventListener("input", () => {
    if (type === "origin") {
      selectedOriginAirport = null;
      renderSelectedAirport("origin", false);

      if (isOriginComposing) {
        return;
      }
    } else {
      selectedDestinationAirport = null;
      renderSelectedAirport("destination", false);

      if (isDestinationComposing) {
        return;
      }
    }

    renderAirportDropdown(type, input.value);
  });

  input.addEventListener("focus", () => {
    renderAirportDropdown(type, input.value);
  });
}

function openResultsSearchPanel() {
  resultsSearchPanel.classList.add("open");
  resultsSearchDim.classList.add("open");
  document.body.classList.add("search-panel-open");
}

function closeResultsSearchPanel() {
  resultsSearchPanel.classList.remove("open");
  resultsSearchDim.classList.remove("open");
  document.body.classList.remove("search-panel-open");
}

function getCurrentParams() {
  return new URLSearchParams(window.location.search);
}

function getTodayText() {
  const today = new Date();
  const yyyy = today.getFullYear();
  const mm = String(today.getMonth() + 1).padStart(2, "0");
  const dd = String(today.getDate()).padStart(2, "0");

  return `${yyyy}-${mm}-${dd}`;
}
function initializeDateLimit() {
  const today = getTodayText();

  departureDateInput.min = today;

  if (!departureDateInput.value || departureDateInput.value < today) {
    departureDateInput.value = today;
  }
}

function loadAirportsFromCache() {
  try {
    const cachedAirports = sessionStorage.getItem(AIRPORT_CACHE_KEY);

    if (!cachedAirports) {
      return;
    }

    const parsedAirports = JSON.parse(cachedAirports);

    if (!Array.isArray(parsedAirports) || parsedAirports.length === 0) {
      return;
    }

    airports = parsedAirports;
    setSelectedAirportsFromUrl();
    enableSearchButton();
  } catch (error) {
    console.warn("공항 캐시를 읽지 못했습니다.", error);
  }
}

async function loadAirports() {
  try {
    const response = await fetch("/api/flights/airports");

    if (!response.ok) {
      throw new Error("공항 목록 조회 실패");
    }

    airports = await response.json();

    sessionStorage.setItem(AIRPORT_CACHE_KEY, JSON.stringify(airports));

    setSelectedAirportsFromUrl();
    enableSearchButton();
  } catch (error) {
    console.error(error);

    if (airports.length > 0) {
      return;
    }

    originAirportInput.placeholder = "공항 목록 조회 실패";
    destinationAirportInput.placeholder = "공항 목록 조회 실패";
    disableSearchButton("공항 목록 조회 실패");
  }
}

function setSelectedAirportsFromUrl() {
  if (!airports || airports.length === 0) {
    disableSearchButton("공항 없음");
    return;
  }

  const params = getCurrentParams();

  selectedOriginAirport =
    findAirportByCode(params.get("origin")) ||
    airports.find((airport) => airport.airportCode === "ICN") ||
    airports[0];

  selectedDestinationAirport =
    findAirportByCode(params.get("destination")) ||
    airports.find((airport) => airport.airportCode === "NRT") ||
    airports.find((airport) => airport.airportCode !== selectedOriginAirport.airportCode) ||
    airports[0];

  renderSelectedAirport("origin");
  renderSelectedAirport("destination");
}

function findAirportByCode(code) {
  if (!code) {
    return null;
  }

  return airports.find((airport) => airport.airportCode === code);
}

function renderSelectedAirport(type, fillInput = true) {
  const airport = type === "origin" ? selectedOriginAirport : selectedDestinationAirport;
  const input = type === "origin" ? originAirportInput : destinationAirportInput;
  const badge = type === "origin" ? originAirportCodeBadge : destinationAirportCodeBadge;

  if (!airport) {
    badge.textContent = "-";

    if (fillInput) {
      input.value = "";
    }

    return;
  }

  badge.textContent = airport.airportCode;

  if (fillInput) {
    input.value = `${airport.cityName} ${airport.airportName} (${airport.airportCode})`;
  }
}

function renderAirportDropdown(type, keyword) {
  const dropdown = type === "origin" ? originAirportDropdown : destinationAirportDropdown;
  const normalizedKeyword = normalizeText(keyword);

  const filteredAirports = filterAirports(normalizedKeyword).slice(0, 12);

  if (filteredAirports.length === 0) {
    dropdown.innerHTML = `
      <div class="airport-empty">
        검색 결과가 없습니다. 국가, 도시, 공항명 또는 공항 코드를 다시 입력해 주세요.
      </div>
    `;
    dropdown.classList.add("open");
    return;
  }

  dropdown.innerHTML = filteredAirports
    .map((airport) => {
      return `
        <button type="button" class="airport-option" data-airport-code="${airport.airportCode}">
          <span class="airport-option-icon">✈</span>

          <span class="airport-option-main">
            <span class="airport-option-title">
              ${airport.cityName} ${airport.airportName}
            </span>
            <span class="airport-option-sub">
              ${airport.countryName} · ${airport.region}
            </span>
          </span>

          <span class="airport-option-code">${airport.airportCode}</span>
        </button>
      `;
    })
    .join("");

  dropdown.querySelectorAll(".airport-option").forEach((button) => {
    button.addEventListener("click", () => {
      const airportCode = button.dataset.airportCode;
      const airport = airports.find((item) => item.airportCode === airportCode);

      if (!airport) {
        return;
      }

      if (type === "origin") {
        selectedOriginAirport = airport;
      } else {
        selectedDestinationAirport = airport;
      }

      renderSelectedAirport(type);
      closeAirportDropdowns();
    });
  });

  dropdown.classList.add("open");
}

function filterAirports(normalizedKeyword) {
  if (!airports || airports.length === 0) {
    return [];
  }

  if (!normalizedKeyword) {
    return airports;
  }

  return airports.filter((airport) => {
    return (
      includesAirportKeyword(airport.countryName, normalizedKeyword) ||
      includesAirportKeyword(airport.countryCode, normalizedKeyword) ||
      includesAirportKeyword(airport.cityName, normalizedKeyword) ||
      includesAirportKeyword(airport.airportName, normalizedKeyword) ||
      includesAirportKeyword(airport.airportCode, normalizedKeyword) ||
      includesAirportKeyword(airport.region, normalizedKeyword)
    );
  });
}

function includesAirportKeyword(value, normalizedKeyword) {
  if (!value) {
    return false;
  }

  return normalizeText(value).includes(normalizedKeyword);
}

function normalizeText(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replaceAll(" ", "");
}

function closeAirportDropdowns() {
  originAirportDropdown.classList.remove("open");
  destinationAirportDropdown.classList.remove("open");
}

function enableSearchButton() {
  resultsSearchBtn.disabled = false;
  resultsSearchBtn.textContent = "검색하기";
}

function disableSearchButton(text) {
  resultsSearchBtn.disabled = true;
  resultsSearchBtn.textContent = text;
}

function changePassengerCount(type, delta) {
  const nextAdultCount = type === "ADULT" ? adultCount + delta : adultCount;
  const nextChildCount = type === "CHILD" ? childCount + delta : childCount;
  const nextInfantCount = type === "INFANT" ? infantCount + delta : infantCount;

  if (nextAdultCount < 1 || nextChildCount < 0 || nextInfantCount < 0) {
    return;
  }

  if (nextAdultCount + nextChildCount + nextInfantCount > 9) {
    return;
  }

  if (nextInfantCount > nextAdultCount) {
    return;
  }

  adultCount = nextAdultCount;
  childCount = nextChildCount;
  infantCount = nextInfantCount;

  renderTravelerCount();
}

function renderTravelerCount() {
  adultCountText.textContent = adultCount;
  childCountText.textContent = childCount;
  infantCountText.textContent = infantCount;

  travelerSummaryText.textContent = createTravelerSummary();

  adultMinusBtn.disabled = adultCount <= 1;
  adultPlusBtn.disabled = getTotalPassengerCount() >= 9;

  childMinusBtn.disabled = childCount <= 0;
  childPlusBtn.disabled = getTotalPassengerCount() >= 9;

  infantMinusBtn.disabled = infantCount <= 0;
  infantPlusBtn.disabled =
    getTotalPassengerCount() >= 9 || infantCount >= adultCount;
}

function createTravelerSummary() {
  const summary = [`성인 ${adultCount}명`];

  if (childCount > 0) {
    summary.push(`소아 ${childCount}명`);
  }

  if (infantCount > 0) {
    summary.push(`유아 ${infantCount}명`);
  }

  return summary.join(", ");
}

function getTotalPassengerCount() {
  return adultCount + childCount + infantCount;
}

function moveToResultsPage() {
  if (!selectedOriginAirport) {
    alert("출발지를 검색해서 선택해 주세요.");
    originAirportInput.focus();
    return;
  }

  if (!selectedDestinationAirport) {
    alert("도착지를 검색해서 선택해 주세요.");
    destinationAirportInput.focus();
    return;
  }

  const origin = selectedOriginAirport.airportCode;
  const destination = selectedDestinationAirport.airportCode;
  const departureDate = departureDateInput.value;

  if (origin === destination) {
    alert("출발지와 도착지는 같을 수 없습니다.");
    return;
  }

  if (!departureDate) {
    alert("가는 날을 선택해 주세요.");
    return;
  }
  if (departureDate < getTodayText()) {
    alert("오늘 이전 날짜는 선택할 수 없습니다.");
    departureDateInput.value = getTodayText();
    return;
  }

  const params = new URLSearchParams();
  params.append("origin", origin);
  params.append("destination", destination);
  params.append("departureDate", departureDate);
  params.append("adultCount", adultCount);
  params.append("childCount", childCount);
  params.append("infantCount", infantCount);

  if (seatClassSelect.value) {
    params.append("seatClass", seatClassSelect.value);
  }

  if (connectionTypeSelect.value) {
    params.append("connectionType", connectionTypeSelect.value);
  }

  if (sortSelect.value) {
    params.append("sort", sortSelect.value);
  }

  window.location.href = `/flights/results?${params.toString()}`;
}

function updateParamAndReload(key, value) {
  const params = getCurrentParams();

  if (value) {
    params.set(key, value);
  } else {
    params.delete(key);
  }

  window.location.href = `/flights/results?${params.toString()}`;
}

async function fetchFlightResults() {
  const params = getCurrentParams();

  const origin = params.get("origin");
  const destination = params.get("destination");
  const departureDate = params.get("departureDate");

  if (!origin || !destination || !departureDate) {
    renderInvalidRequest();
    return;
  }

  renderLoading();

  try {
    const response = await fetch(`/api/flights/search?${params.toString()}`);

    if (!response.ok) {
      throw new Error("항공권 검색 실패");
    }

    const data = await response.json();

    renderSearchResult(data);
  } catch (error) {
    console.error(error);
    renderError();
  }
}

function renderLoading() {
  resultSummary.textContent = "항공권을 검색하는 중입니다.";

  flightResultGrid.innerHTML = `
    <div class="loading-result">
      항공권 데이터를 불러오는 중입니다.
    </div>
  `;
}

function renderInvalidRequest() {
  compactRouteText.textContent = "검색 조건이 올바르지 않습니다.";
  compactConditionText.textContent = "출발지, 도착지, 날짜를 다시 선택해 주세요.";
  resultSummary.textContent = "검색 조건이 부족합니다.";

  flightResultGrid.innerHTML = `
    <div class="empty-result">
      검색 조건이 올바르지 않습니다. 항공권 검색 화면에서 다시 검색해 주세요.
    </div>
  `;
}

function renderError() {
  resultSummary.textContent = "항공권 검색 중 오류가 발생했습니다.";

  flightResultGrid.innerHTML = `
    <div class="empty-result">
      항공권 데이터를 불러오지 못했습니다. 검색 조건 또는 서버 로그를 확인해 주세요.
    </div>
  `;
}

function renderSearchResult(data) {
  const options = data.options || [];
  const passengerText = createTravelerSummary();

  compactRouteText.textContent =
    `${data.originAirportCode} → ${data.destinationAirportCode}`;

  compactConditionText.textContent =
    `${data.departureDate} · ${passengerText}`;

  resultSummary.textContent =
    `${data.originAirportName} (${data.originAirportCode}) → ` +
    `${data.destinationAirportName} (${data.destinationAirportCode}) · ` +
    `${data.departureDate} · ${options.length}개 항공권`;

  if (options.length === 0) {
    flightResultGrid.innerHTML = `
      <div class="empty-result">
        검색 결과가 없습니다. 다른 날짜, 노선 또는 조건으로 다시 검색해 주세요.
      </div>
    `;
    return;
  }

  flightResultGrid.innerHTML = options
    .map((option) => renderFlightOptionCard(option, data))
    .join("");
}

function renderFlightOptionCard(option, data) {
  const adultBasePrice = Number(option.price);
  const totalPrice = Number(option.totalPrice);
  const passengerSummary = option.passengerSummary || createTravelerSummary();

  const segmentPathText = createSegmentPathText(option, data);
  const connectionText = createConnectionText(option);

  return `
    <article class="flight-option-card">
      <div class="airline-block">
        <h3>${option.airlineName}</h3>
        <p class="airline-meta">
          ${option.airlineTierDescription} · ${option.airlineCode}
        </p>

        <div class="badge-row">
          <span class="flight-badge">${option.seatClassDescription}</span>
          <span class="flight-badge">${option.connectionTypeDescription}</span>
        </div>
      </div>

      <div class="route-block">
        <div>
          <div class="route-time">${formatTime(option.departureTime)}</div>
          <div class="route-airport">${data.originAirportCode}</div>
        </div>

        <div class="route-center">
          <div class="duration-text">${option.totalDurationText}</div>
          <div class="route-line"></div>
          <div class="segment-path">${segmentPathText}</div>
          <div class="layover-text">${connectionText}</div>
        </div>

        <div>
          <div class="route-time">${formatTime(option.arrivalTime)}</div>
          <div class="route-airport">
            ${data.destinationAirportCode}
            ${option.arrivalDate !== data.departureDate ? ` · ${option.arrivalDate}` : ""}
          </div>
        </div>
      </div>

      <div class="price-block">
        <p class="price-label">성인 1인 기준</p>
        <p class="price">₩${formatPrice(adultBasePrice)}</p>
        <div class="passenger-summary">${passengerSummary}</div>
        <div class="total-price">
          예상 총액 ₩${formatPrice(totalPrice)}
        </div>
        <a href="#" class="select-flight-btn">선택하기</a>
      </div>
    </article>
  `;
}

function getSortedSegments(option) {
  if (!Array.isArray(option.segments)) {
    return [];
  }

  return [...option.segments].sort((a, b) => {
    return Number(a.segmentOrder || 0) - Number(b.segmentOrder || 0);
  });
}

function createSegmentPathText(option, data) {
  const segments = getSortedSegments(option);

  if (segments.length === 0) {
    if (option.connectionType === "ONE_STOP") {
      return `${data.originAirportCode} → ${option.layoverAirportCode || "-"} → ${data.destinationAirportCode}`;
    }

    return `${data.originAirportCode} → ${data.destinationAirportCode}`;
  }

  const airportCodes = [];

  airportCodes.push(segments[0].originAirportCode);

  segments.forEach((segment) => {
    airportCodes.push(segment.destinationAirportCode);
  });

  return airportCodes
    .filter(Boolean)
    .join(" → ");
}

function createConnectionText(option) {
  const segments = getSortedSegments(option);

  if (segments.length <= 1) {
    return "직항";
  }

  const layoverTexts = segments
    .slice(0, -1)
    .map((segment) => {
      const airportCode = segment.destinationAirportCode || "-";
      const layoverText = segment.layoverAfterText
        ? ` · 대기 ${segment.layoverAfterText}`
        : "";

      return `${airportCode}${layoverText}`;
    });

  return `경유 ${layoverTexts.join(", ")}`;
}

function formatTime(timeText) {
  if (!timeText) {
    return "-";
  }

  return String(timeText).slice(0, 5);
}

function formatPrice(price) {
  if (Number.isNaN(Number(price))) {
    return "-";
  }

  return Number(price).toLocaleString("ko-KR");
}